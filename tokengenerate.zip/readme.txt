///////////// Ahmed Sn
ملاحظة فيه حاجة اسمها 
   await page.waitForSelector('.inputWrapper_f8bc55', { visible: true });

ده عبارة عن selector بيتغير من جهاز لاخر فانت لو ما ضغط على الزر عتروح دوس فى جوج كروم على AlT + Shift + I 

وعتحدد الزرار العاوز يضغط عليه و من html عتلاقى الزرار عتضغط كليك يمين و تعمل copy selector

بس كده وتحطه بين "" بدل ده .inputWrapper_f8bc55