const puppeteer = require('puppeteer-extra');
const fs = require('fs');
const path = require('path');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');


puppeteer.use(StealthPlugin());

function generateRandomName() {
  const adjectives = ['Swift', 'Cool', 'Wise', 'Brave', 'Bright'];
  const animals = ['Fox', 'Eagle', 'Shark', 'Tiger', 'Wolf'];
  const randomAdjective = adjectives[Math.floor(Math.random() * adjectives.length)];
  const randomAnimal = animals[Math.floor(Math.random() * animals.length)];
  const randomNumber = Math.floor(Math.random() * 1000);
  return `${randomAdjective}${randomAnimal}${randomNumber}`;
}


async function randomMouseMovement(page) {
  const x = Math.random() * 200 + 50; 
  const y = Math.random() * 200 + 50; 
  await page.mouse.move(x, y, { steps: Math.floor(Math.random() * 10) + 5 }); 
}


async function waitFor(delay) {
  return new Promise((resolve) => setTimeout(resolve, delay));
}


async function slowType(page, selector, text, minDelay = 200, maxDelay = 600) {
  await page.click(selector); 
  for (const char of text) {
    await page.keyboard.press(char);
    const delay = Math.floor(Math.random() * (maxDelay - minDelay + 1) + minDelay);
    await waitFor(delay); 
  }
}


async function retrieveVerificationEmail(emailService, emailAddress) {
  console.log('Retrieving verification email...');
  

  const verificationEmail = await emailService.getLatestEmail(emailAddress);
  if (verificationEmail) {
    const verificationLink = extractVerificationLink(verificationEmail);
    await page.goto(verificationLink, { waitUntil: 'load' });
    console.log('Email verified successfully!');
  } else {
    console.log('No verification email found.');
  }
}


function extractVerificationLink(email) {

  const regex = /https?:\/\/[^\s]+/; 
  const match = email.match(regex);
  return match ? match[0] : null;
}


async function processDiscordJoin() {
  const browser = await puppeteer.launch({
    headless: false, 
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
    ignoreDefaultArgs: ['--enable-automation'], 
    defaultViewport: null, 
  });

  const page = await browser.newPage();


  await page.evaluateOnNewDocument(() => {
    Object.defineProperty(navigator, 'webdriver', { get: () => false });
    window.chrome = {
      runtime: {},
      app: {
        isInstalled: false
      }
    };
    Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
    Object.defineProperty(navigator, 'plugins', { get: () => [{ description: 'some description' }] });
    

    Object.defineProperty(screen, 'width', { get: () => Math.floor(Math.random() * (1920 - 1366) + 1366) });
    Object.defineProperty(screen, 'height', { get: () => Math.floor(Math.random() * (1080 - 768) + 768) });


    const randomUserAgent = `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${Math.floor(Math.random() * (100 - 85) + 85)}.0.4183.121 Safari/537.36`;
    Object.defineProperty(navigator, 'userAgent', { get: () => randomUserAgent });
  });

  try {
  
    await page.goto('https://discord.gg/cM9w7s4rz', { waitUntil: 'load' });

   
    await page.waitForSelector('.inputWrapper_f8bc55', { visible: true });

  
    const randomName = generateRandomName();
    console.log('Using the name:', randomName);

    
    await randomMouseMovement(page);

   
    await slowType(page, '.inputWrapper_f8bc55 input', randomName, 300, 600);


    await randomMouseMovement(page);


    await page.click('button.button_b83a05, button.button_dd4f85', { delay: Math.random() * 200 + 100 });


    console.log('Please wait until you solve the CAPTCHA completely...');


    await page.waitForFunction(() => localStorage.getItem('token') !== null);


    const token = await page.evaluate(() => localStorage.getItem('token'));

    if (token) {
      const tokenFilePath = path.join(__dirname, 'tokens.txt');

      fs.appendFileSync(tokenFilePath, token + '\n');
      console.log('Token saved successfully:', token);
    } else {
      console.log('Token not found.');
    }

 
    // const emailService = new EmailService();
    // const emailAddress = "your_temp_email@example.com"; 
    // await retrieveVerificationEmail(emailService, emailAddress);

    return true;

  } catch (error) {
    console.error('An error occurred during the process:', error);
    return false;
  } finally {
   
    await browser.close();
  }
}


async function startProcessWithRetries() {
  while (true) {
    const success = await processDiscordJoin();
    if (success) {
      console.log('Token retrieved and saved successfully!');
    } else {
      console.log('Failed to retrieve token, retrying after 3 minutes...');
    }
    
   
    await waitFor(180000); // wait for 3 minutes
  }
}


startProcessWithRetries();
